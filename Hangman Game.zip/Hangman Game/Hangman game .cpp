#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstdlib>

using namespace std;
vector<string> words = {
    "apple", "banana", "cherry", "grape", "orange",
    "strawberry", "pineapple", "watermelon", "blueberry", "kiwi",
    "mango", "peach", "pear", "plum", "raspberry",
    "blackberry", "lemon", "lime", "coconut", "pomegranate",
    "fig", "apricot", "guava", "passionfruit", "dragonfruit",
    "cranberry", "melon", "nectarine", "papaya", "tangerine"};

const int maxAttempts = 3;

int getRandomNumber(int max)
{
    return rand() % max;
}

char getUserGuess()
{
    char guess;
    cout << "Enter your guess: ";
    cin >> guess;
    return tolower(guess);
}

bool isWordGuessed(const string &word, const string &guessedLetters)
{
    for (char c : word)
    {
        if (guessedLetters.find(c) == string::npos)
        {
            return false;
        }
    }
    return true;
}

void displayWordWithGuesses(const string &word, const string &guessedLetters)
{
    for (char c : word)
    {
        if (guessedLetters.find(c) != string::npos)
        {
            cout << c << " ";
        }
        else
        {
            cout << "_ ";
        }
    }
    cout << endl;
}

int main()
{
    srand(time(0));
    string selectedWord = words[getRandomNumber(words.size())];
    string guessedLetters;

    cout << "Welcome to Hangman!" << endl;

    int attempts = 0;
    while (attempts < maxAttempts)
    {
        cout << "Attempts left: " << maxAttempts - attempts << endl;
        displayWordWithGuesses(selectedWord, guessedLetters);

        char guess = getUserGuess();
        guessedLetters += guess;

        if (selectedWord.find(guess) == string::npos)
        {
            cout << "Unfortunately, the hangman's noose tightens, and your journey ends here. Game over!" << endl;
            attempts++;
        }

        if (isWordGuessed(selectedWord, guessedLetters))
        {
            cout << "Victory! You've outsmarted the gallows and saved the day. Well done!" << endl;
            break;
        }
    }

    if (attempts == maxAttempts)
    {
        cout << "You're out of attempts! The word was: " << selectedWord << endl;
    }

    cout << "Thanks for playing Hangman!" << endl;

    return 0;
}
